import React from 'react';


function Images() {


  return (

    <div class ="container banner">
         <br/>
    {/* <img  style = {{height : "460px" , width : "1300px"}} src="./banner.png" alt=""/>   */}
    <img  style = {{size : "reflex" , width: "100%" , height: "auto" }} src="./banner.png" alt=""/>  

    </div>
  )

}

export default Images;
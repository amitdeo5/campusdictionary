import React from "react";
function text(){
    return(
        <div class="container">
          

        <div class="row">
        <h3 style = {{fontFamily : "helvetica"}} class="center head-text">Campus Dictionary... is one point solution for</h3> <br/><br/><br/>
        
        
          <div class="col l6 s12 apni">
            <h5 class="black-text">Companies / HRs :</h5>
            <p class="white-text text-lighten-0" style = {{fontFamily : "helvetica" , textAlign : "justify"}}   >We aim to provide them the best reputated colleges with there previous placement records. This reduces the time of college searching & risk of wastage of time. <br/>Moreover, HR's can directly schedule a meet with TPC at there desired date & time via this platform.</p>
          </div>
          <div class="col l4 offset-l2 s12 apni">
            <h5 class="black-text">College - TPC :</h5>
            <p class="white-text text-lighten-0" style = {{fontFamily : "helvetica" , textAlign : "justify"}}   >We aim to provide the platform to the colleges to showcase there placement records and their students achivements. <br/> <br/> This will directly impress the HRs to schedule meeting with them for placement drives in campus.</p>
          </div>


          <div class="col l4 offset-l2 s12 apni">
            <h5 class="black-text">Students :</h5>
            <p class="white-text text-lighten-0" style = {{fontFamily : "helvetica" , textAlign : "justify"}} > With this platform, our aim is to guide the ambitious students, to provide them with the complete placement records of various collegs in India <br/><br/> This will aware them enough so that they can choose the right option for them.</p>
          </div>

          <br/><br/><br/>



        </div>
      </div>
    )
}
export default text;
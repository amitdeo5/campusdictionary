const data={
    cardData:[
        {
            id:1,
            pic:'https://images.shiksha.com/mediadata/images/1604055117phpA7f02X.jpeg',
            name:'UIET Chandigarh',
            description:'NIRF ##',
            meet_link:"https://calendly.com/campusdictionary/uietchd"
        },
        {
            id:2,
            pic:'https://images.shiksha.com/mediadata/images/1608298098php5uuM0z.jpeg',
            name:'NIT Kurukshetra',
            description:'NIRF ##',
            meet_link:"https://calendly.com/campusdictionary/meeting-with-lovely-professional-university-clone"
        },
        {
            id:3,
            pic:'https://images.shiksha.com/mediadata/images/1488259134phpShnPJa.jpeg',
            name:'Lovely Profession University',
            description:'NIRF ##',
            meet_link:"https://calendly.com/campusdictionary/meeting-with-chitkara-university-clone"
        },
        {
            id:4,
            pic:'https://images.shiksha.com/mediadata/images/1607000135php5P1CAG.jpeg',
            name:'Chitkara University',
            description:'NIRF ##',
            meet_link:"https://calendly.com/campusdictionary/meeting-with-pec-chandigarh-clone"
        },
        {
            id:5,
            pic:'https://images.shiksha.com/mediadata/images/1488191355phpZpAtvz.jpeg',
            name:'PEC Chandigarh',
            description:'NIRF ##',
            meet_link:"https://calendly.com/campusdictionary/meeting-with-uiet-pu-chandigarh-clone"
        },
        {
            id:6,
            pic:'https://images.shiksha.com/mediadata/images/1563363984php9llevZ.jpeg',
            name:'UIET PUSSGRC',
            description:'NIRF ##',
            meet_link:"https://calendly.com/campusdictionary/meeting-with-nit-kurukshetra-clone"
        },

        {
            id:7,
            pic:'https://images.shiksha.com/mediadata/images/1563363984php9llevZ.jpeg',
            name:'CCET Chandigarh',
            description:'NIRF ##',
            meet_link:"https://calendly.com/campusdictionary/meeting-with-pu-ssgrc-clone"
        },

        {
            id:8,
            pic:'https://images.shiksha.com/mediadata/images/1563363984php9llevZ.jpeg',
            name:'IIT Ropar',
            description:'NIRF ##',
            meet_link:"https://calendly.com/campusdictionary/meeting-with-ccet-chandigarh-clone"
        }



    ]
}

export default data;